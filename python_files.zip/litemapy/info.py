LITEMATIC_VERSION = 5  # Litematic version we are trying to imitate from Litematica
MC_DATA_VERSION = 1631
DEFAULT_NAME = "Unnamed"  # Default name given to schematics and regions if unspecified
LITEMAPY_NAME = "Litemapy"  # Used to identify schematic created with Litemapy in metadata
LITEMAPY_VERSION = "0.6.0b0"  # Unique version string
